import java.util.*;


public class Movimiento {
	private int numero;
	private Date fecha;
	private String concepto;
	private float monto;
	
	public Movimiento(Date fecha, String concepto, float monto, int numero) {
		this.numero = numero;
		this.fecha = fecha;
		this.concepto = concepto;
		this.monto = monto;
	}
}
