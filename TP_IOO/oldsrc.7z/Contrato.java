import java.util.*;

public class Contrato {
	private int numero;
	private String estado;
	private Date fechaEntrada;
	private Date fechaFinal;
	private Vector<MediodePago> mediosdePago;
	private CuentaCorriente cuentaCorriente;
	private Cliente cliente;
	private Cochera cochera;
	
	public Contrato(Date fechaEntrada, Date fechaFinal, Cliente cliente, Cochera cochera, int numero) {
		this.numero = numero;
		this.estado = "Activo";
		this.fechaEntrada = fechaEntrada;
		this.fechaFinal = fechaFinal;
		this.cliente =cliente;
		this.cochera = cochera;
		CuentaCorriente cc = new CuentaCorriente();
		this.cuentaCorriente = cc;
	}

	public Cliente GetCliente() {
		return cliente;
	}

	public void SetEstado(String estado) {
		this.estado = estado;
	}
	
	public void AltaTarjeta(String entidadEmisora, int numeroTarjeta, Date fechaVencimiento) {
		int numero = mediosdePago.size() + 1;
		MediodePago tc = BuscarTarjeta(numeroTarjeta);
		if (tc != null) {
			tc.SetEstado("Activo");
		}
		else {
			tc = new TarjetadeCredito(entidadEmisora, numeroTarjeta, fechaVencimiento, numero);
			mediosdePago.add(tc);
		}
	}
	
	public MediodePago BuscarTarjeta(int numero) {
		for (int i = 0; i < mediosdePago.size(); i++) {
			if (mediosdePago.elementAt(i) instanceof TarjetadeCredito) {
				if (mediosdePago.elementAt(i).GetNumeroTarjeta() == numero) {
					return mediosdePago.elementAt(i);
				}
			}
		}
		return null;
	}
	
	public MediodePago BuscarCBU(int CBU) {
		for (int i = 0; i < mediosdePago.size(); i++) {
			if (mediosdePago.elementAt(i) instanceof DebitoBancario) {
				if (mediosdePago.elementAt(i).GetCBU() == CBU) {
					return mediosdePago.elementAt(i);
				}
			}
		}
		return null;
	}
	
	public void AltaCBU(String entidadBancaria, int CBU) {
		int numero = mediosdePago.size() + 1;
		MediodePago db = BuscarCBU(CBU);
		if (db != null) {
			db.SetEstado("Activo");
		}
		else {
			db = new DebitoBancario(entidadBancaria, CBU, numero);
			mediosdePago.add(db);
		}
	}
	
	
	public MediodePago BuscarEfectivo(){
		for (int i = 0; i < mediosdePago.size(); i++) {
			if (mediosdePago.elementAt(i) instanceof Efectivo) {
				return mediosdePago.elementAt(i);
			}
		}
		return null;
	}
	
	public void AltaEfectivo () {
		int numero = mediosdePago.size() + 1;
		MediodePago ef = BuscarEfectivo();
		if (ef != null) {
			ef.SetEstado("Activo");
		}
		else {
			ef = new Efectivo(numero);
			mediosdePago.add(ef);
		}
	}
	
	
	public void BajaTarjeta(int numero){
		MediodePago tc = BuscarTarjeta(numero);
		if (tc != null) {
			tc.SetEstado("Inactivo");
		}
	}

	public void BajaCBU(int CBU) {
		MediodePago db = BuscarCBU(CBU);
		if (db != null) {
			db.SetEstado("Inactivo");
		}
	}
	
	
	public void BajaEfectivo () {
		MediodePago ef = BuscarEfectivo();
		if (ef != null) {
			ef.SetEstado("Inactivo");
		}
	}
	
	public void ProcesarMovimiento (Date fecha, String concepto, float monto) {
		this.cuentaCorriente.ProcesarMovimiento(fecha, concepto, monto);
		float saldo = this.cuentaCorriente.GetSaldo();
		if (saldo > 0) {
			this.cochera.SetEstado("Ocupada");
		}
	}
	
	public void BajaContrato() {
		this.SetEstado("Inactivo");
		this.cochera.SetEstado("Libre");
		this.cochera.SetAuto(null);
	}
	
	public void ActualizarEstadoCochera() {
		if (this.estado == "Activo") {
			if (this.cuentaCorriente.GetSaldo() < 0) {
				this.cochera.SetEstado("Bloqueada");
			}
		}
		else {
			this.cochera.SetEstado("Libre");
		}
	}
	
	public void ProcesarCuota(Date fecha) {
		float monto = this.cochera.GetPrecio();
		String concepto = "Cuota del mes";
		this.cuentaCorriente.ProcesarMovimiento(fecha, concepto, monto);
	}
	
	public int GetNumero(){
		return this.numero;
	}
}
