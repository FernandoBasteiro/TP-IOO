import java.util.*;

public class Cliente {
	private int dni;
	private String nombre;
	private String domicilio;
	private int telefono;
	private String mail;
	private String estado;
	
	public Cliente(int dni, String nombre, String domicilio, int telefono, String mail, String estado) {
		this.dni = dni;
		this.nombre = nombre;
		this.domicilio = domicilio;
		this.telefono = telefono;
		this.mail = mail;
		this.estado = estado;
	}

	public void SetDni(int dni) {
		this.dni = dni;
	}

	public void SetNombre(String nombre) {
		this.nombre = nombre;
	}

	public void SetDomicilio(String domicilio) {
		this.domicilio = domicilio;
	}

	public void SetTelefono(int telefono) {
		this.telefono = telefono;
	}

	public void SetMail(String mail) {
		this.mail = mail;
	}

	public void SetEstado(String estado) {
		this.estado = estado;
	}
	
	public int GetDni() {
		return this.dni;
	}
	
}
