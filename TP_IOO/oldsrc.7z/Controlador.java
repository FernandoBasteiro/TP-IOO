import java.util.*;


public class Controlador {
	private Vector<Cochera> cocheras;
	private Vector<Contrato> contratos;
	private Vector<Cliente> clientes;
	private Contrato contrato;
	private Cliente cliente;
	private Cochera cochera;
	
	public Contrato BuscarContrato(int numero) {
		for (int i = 0; i < contratos.size(); i++) {
			if (contratos.elementAt(i).GetNumero() == numero) {
				return contratos.elementAt(i);
			}
		}
		return null;
	}
	
	public Cochera BuscarCocheraDisponible(String tamanio) {
		for (int i = 0; i < cocheras.size(); i++) {
			if (cocheras.elementAt(i).GetTamanio().compareTo(tamanio) == 0 && cocheras.elementAt(i).GetEstado().compareTo("Libre") == 0) {
				return cocheras.elementAt(i);
			}
		}
		return null;
	}
	
	public void AltaTarjeta(String entidadEmisora, int numero, Date fechaVencimiento) {
		this.contrato.AltaTarjeta(entidadEmisora, numero, fechaVencimiento);
	}
	
	public void AltaCBBU(String entidadBancaria, int CBU) {
		this.contrato.AltaCBU(entidadBancaria, CBU);		
	}
	
	public void AltaEfectivo() {
		this.contrato.AltaEfectivo();
	}
	
	public void BajaTarjeta(int numero) {
		this.contrato.BajaTarjeta(numero);
	}
	
	public void BajaCBU(int CBU) {
		this.contrato.BajaCBU(CBU);
	}
	
	public void BajaEfectivo() {
		this.contrato.BajaEfectivo();
	}
	
	public void ProcesarMovimiento(Date fecha, String concepto, float monto) {
		this.contrato.ProcesarMovimiento(fecha, concepto, monto);
	}
	
	public void AltaContrato(String tamanio, String patente, String modelo, String marca, Date fechaEntrada, Date fechaSalida) {
		int numero = contratos.size() + 1;
		Cochera cochera = BuscarCocheraDisponible(tamanio);
		Contrato nuevocontrato = new Contrato(fechaEntrada, fechaSalida, this.cliente, cochera, numero);
		cochera.SetEstado("Ocupada");
		cochera.CrearAuto(patente, marca, modelo);
		contratos.add(nuevocontrato);
	}
	
	public void BajaContrato() {
		contrato.BajaContrato();
	}
	
	public void ActualizarEstadoCocheras() {
		for (int i = 0; i < contratos.size(); i++) {
			contratos.elementAt(i).ActualizarEstadoCochera();
		}
	}

	public void CrearCochera(String tamanio, float precio) {
		int numero = cocheras.size() + 1;
		String estado = "Libre";
		Cochera nuevaCochera = new Cochera(numero, estado, tamanio, precio);
		cocheras.add(nuevaCochera);
	}
	
	public void ProcesarCuotas(Date fecha) {
		for (int i = 0; i < contratos.size(); i++) {
			contratos.elementAt(i).ProcesarCuota(fecha);
		}
	}
	
	public Cliente BuscarCliente(int dni) {
		for (int i = 0; i < clientes.size(); i++) {
			if (clientes.elementAt(i).GetDni() == dni) {
				return clientes.elementAt(i);
			}
		}
		return null;
	}
	
	public void AltaClienteNuevo(int dni, String nombre, String domicilio, int telefono, String mail) {
		String estado = "Activo";
		Cliente nuevoCliente = new Cliente(dni, nombre, domicilio, telefono, mail, estado);
		clientes.add(nuevoCliente);
	}
	
	public void BajaCliente() {
		String estado = "Inactivo";
		this.cliente.SetEstado(estado);
		for (int i = 0; i < contratos.size(); i++) {
			if (this.cliente == contratos.elementAt(i).GetCliente()) {
				contratos.elementAt(i).BajaContrato();
			}
		}
		
	}
	
	public void ModificarCliente(int dni, String nombre, String domicilio, int telefono, String mail, String estado) {
		this.cliente.SetDni(dni);;
		this.cliente.SetNombre(nombre);
		this.cliente.SetDomicilio(domicilio);
		this.cliente.SetTelefono(telefono);
		this.cliente.SetMail(mail);
		this.cliente.SetEstado(estado);
	}
	
	public boolean ExisteCliente(int dni) {
		SetCliente(BuscarCliente(dni));
		if (cliente != null) {
			return true;
		}
		else {
			return false;
		}
	}
	
	public boolean ExisteContrato(int numero) {
		SetContrato(BuscarContrato(numero));
		if (contrato != null) {
			return true;
		}
		else {
			return false;
		}
	}

	public void SetContrato(Contrato contrato) {
		this.contrato = contrato;
	}

	public void SetCliente(Cliente cliente) {
		this.cliente = cliente;
	}
	
	

}