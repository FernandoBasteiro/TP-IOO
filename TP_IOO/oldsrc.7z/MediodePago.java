
public abstract class MediodePago {
	protected int numero;
	protected String estado;
	
	public void SetEstado(String estado) {
		this.estado = estado;
	}
}
