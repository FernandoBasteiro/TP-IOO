import java.util.*;

public class Efectivo extends MediodePago {
	public Efectivo (int numero) {
		this.numero = numero;
		this.estado = "Activo";
	}
}
