import java.util.*;

public class TarjetadeCredito extends MediodePago {
	private String entidadEmisora;
	private int numeroTarjeta;
	private Date fechaVencimiento;
	
	public TarjetadeCredito (String entidadEmisora, int numeroTarjeta, Date fechaVencimiento, int numero) {
		this.estado = "Activo";
		this.numero = numero;
		this.entidadEmisora = entidadEmisora;
		this.numeroTarjeta = numeroTarjeta;
		this.fechaVencimiento = fechaVencimiento;
	}

	public int GetNumeroTarjeta() {
		return numeroTarjeta;
	}
	

}
