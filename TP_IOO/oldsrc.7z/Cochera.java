import java.util.*;

public class Cochera {
	private int numeroCochera;
	private String estado;
	private String tamanio;
	private float precio;
	private Auto auto;
	
	public Cochera(int nroCochera, String estado, String tamanio, float precio) {
		this.numeroCochera = nroCochera;
		this.estado = estado;
		this.tamanio = tamanio;
		this.precio = precio;
		this.auto = null;
	}
	
	public void SetEstado(String estado) {
		this.estado = estado;
	}
	
	public void SetAuto(Auto auto) {
		this.auto = auto;
	}

	public float GetPrecio() {
		return this.precio;
	}
	
	public void CrearAuto(String patente, String marca, String modelo) {
		Auto a = new Auto(patente, marca, modelo);
		this.auto = a;
	}
	
	public String GetTamanio() {
		return this.tamanio;
	}
	
	public String GetEstado() {
		return this.estado;
	}
}
