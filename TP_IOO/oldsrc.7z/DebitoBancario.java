import java.util.*;

public class DebitoBancario extends MediodePago {
	private String entidadBancaria;
	private int CBU;
	
	public DebitoBancario(String entidadBancaria, int CBU, int numero) {
		this.entidadBancaria = entidadBancaria;
		this.numero = numero;
		this.CBU = CBU;
		this.estado = "Activo";
	}

	public int GetCBU() {
		return CBU;
	}
	
}
