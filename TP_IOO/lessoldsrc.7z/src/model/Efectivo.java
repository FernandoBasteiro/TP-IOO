package model;

public class Efectivo extends MediodePago {
	
	private static final String ACTIVO = "Activo";
	
	public Efectivo(){
		super(ACTIVO);
	}
	
}
