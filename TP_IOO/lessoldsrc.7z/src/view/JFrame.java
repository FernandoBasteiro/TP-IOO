package view;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


import javax.swing.JButton;
import javax.swing.WindowConstants;

import controller.Controlador;

public class JFrame  extends javax.swing.JFrame {
	private JButton altaCliente;
	private JButton modCliente;
	private JButton bajaCliente;
	private JButton altaCochera;
	private Controlador controlador;
	
	public static void main(String[] args) 
	{
		JFrame inst = new JFrame();
		inst.setVisible(true);
	}
	
	public JFrame()
	{
		controlador = new Controlador();
		initGUI();
	}
	
	private void initGUI() 
	{
		try 
		{
			setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
			getContentPane().setLayout(null);
			pack();
			setSize(390, 400);
			
			altaCliente = new JButton();
			getContentPane().add(altaCliente);
			altaCliente.setText("Alta Cliente");
			altaCliente.setBounds(25, 25, 150, 28);
			altaCliente.setVisible(true);
			altaCliente.addActionListener(new ActionListener()
			{
				public void actionPerformed(ActionEvent evt) 
				{
					AltaCliente ac = new AltaCliente(controlador);
					ac.setVisible(true);
				}
			});
			
			modCliente = new JButton();
			getContentPane().add(modCliente);
			modCliente.setText("Modificar Cliente");
			modCliente.setBounds(200, 25, 150, 28);
			modCliente.setVisible(true);
			modCliente.addActionListener(new ActionListener()
			{
				public void actionPerformed(ActionEvent evt) 
				{
					ModCliente mc = new ModCliente(controlador);
					mc.setVisible(true);
				}
			});

			
			bajaCliente = new JButton();
			getContentPane().add(bajaCliente);
			bajaCliente.setText("Baja Cliente");
			bajaCliente.setBounds(25, 75, 150, 28);
			bajaCliente.setVisible(true);
			bajaCliente.addActionListener(new ActionListener()
			{
				public void actionPerformed(ActionEvent evt) 
				{
					BajaCliente bc = new BajaCliente(controlador);
					bc.setVisible(true);
				}
			});

			
			altaCochera = new JButton();
			getContentPane().add(altaCochera);
			altaCochera.setText("Alta Cochera");
			altaCochera.setBounds(200, 75, 150, 28);
			altaCochera.setVisible(true);
			altaCochera.addActionListener(new ActionListener()
			{
				public void actionPerformed(ActionEvent evt) 
				{
					AltaCochera ac = new AltaCochera(controlador);
					ac.setVisible(true);
				}
			});

		} 
		catch (Exception e) {
			e.printStackTrace();
		}
	}

}
